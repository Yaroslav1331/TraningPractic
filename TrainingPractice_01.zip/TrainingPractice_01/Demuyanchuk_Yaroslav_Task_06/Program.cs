﻿using System;

namespace Demuyanchuk_Yaroslav_Task_06
{
    class Program
    {
        static void Main(string[] args)
        {
            bool _start = true;
            string[] _person = new string[0], _proff = new string[0];
            while (_start)
            {
                Console.WriteLine("Введите номер команды: ");
                Console.WriteLine("1 - Добавить новое досье");
                Console.WriteLine("2 - Вывести все досье");
                Console.WriteLine("3 - Удалить досье");
                Console.WriteLine("4 - Поиск по фамилии");
                Console.WriteLine("5 - Выход");

                switch (Console.ReadLine())
                {
                    case "1":
                        AddPerson(ref _proff, ref _person);
                        break;
                    case "2":
                        ShowPerson(ref _proff, ref _person);
                        break;
                    case "3":
                        DeletePerson(ref _proff, ref _person);
                        break;
                    case "4":
                        SearchPerson(ref _proff, ref _person);
                        break;
                    case "5":
                        _start = false;
                        break;
                }
            }
            Console.WriteLine("Программа завершила работу.");
        }
        public static void AddPerson(ref string[] _proff, ref string[] _person)
        {
            string[] tempPerson = new string[_person.Length + 1];
            string[] tempPost = new string[_proff.Length + 1];

            for (int i = 0; i < _person.Length; i++)
            {
                tempPerson[i] = _person[i];
                tempPost[i] = _proff[i];
            }

            _person = tempPerson;
            _proff = tempPost;
            Console.WriteLine("Введите ФИО сотрудника");
            _person[_person.Length - 1] = Console.ReadLine();
            Console.WriteLine("Введите должность сотрудника");
            _proff[_proff.Length - 1] = Console.ReadLine();
            Console.WriteLine();
        }

        public static void ShowPerson(ref string[] _proff, ref string[] _person)
        {
            Console.WriteLine();
            Console.WriteLine("Список всех досье:");

            for (int i = 0; i < _person.Length; i++)
            {
                if (_person[i] != "" && _proff[i] != "")
                {
                    Console.WriteLine((i + 1) + "-" + _person[i] + "-" + _proff[i]);
                }
            }

            Console.WriteLine();
        }

        public static void DeletePerson(ref string[] _proff, ref string[] _person)
        {
            int uselessIndexArray;
            string[] tempPost = new string[_proff.Length - 1];
            string[] tempPerson = new string[_person.Length - 1];
            Console.WriteLine("Введите порядковый номер досье, который вы хотите удалить: ");
            ShowPerson(ref _proff, ref _person);
            uselessIndexArray = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < uselessIndexArray - 1; i++)
            {
                tempPerson[i] = _person[i];
                tempPost[i] = _proff[i];
            }

            for (int i = uselessIndexArray; i < _proff.Length; i++)
            {
                tempPost[i - 1] = _proff[i];
                tempPerson[i - 1] = _person[i];
            }

            _proff = tempPost;
            _person = tempPerson;
        }

        public static void SearchPerson(ref string[] _proff, ref string[] _person)
        {
            string _inputSurname, _surnameSymbols = "";
            int indexArray = 0;
            Console.WriteLine("Для поиска досье введите фамилию: ");
            _inputSurname = Console.ReadLine();

            for (int i = 0; i < _person.Length; i++)
            {
                for (int j = 0; j < _person[i].Length; j++)
                {
                    if (_person[i][j] == ' ')
                    {
                        break;
                    }
                    _surnameSymbols += _person[i][j];
                }
                if (_surnameSymbols == _inputSurname)
                {
                    indexArray = i;
                    break;
                }
                else
                {
                    _surnameSymbols = "";
                }
            }
            if (_surnameSymbols == "")
            {
                Console.WriteLine("Такое досье не было найдено!");
            }
            else
            {
                Console.WriteLine("Досье найдено!");
                Console.WriteLine((indexArray + 1) + "-" + _person[indexArray] + "-" + _proff[indexArray]);
            }
        }
    }
}


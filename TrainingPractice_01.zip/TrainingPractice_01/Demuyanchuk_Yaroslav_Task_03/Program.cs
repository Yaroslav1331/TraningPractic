﻿using System;

namespace Demuyanchuk_Yaroslav_Task_03
{
    class Program
    {
        static void Main(string[] args)
        {
            string _pass = "traning";
            bool _message = false;
            Console.WriteLine("Программа для проверки пароля. У вас 3 попытки. При 3 неудачах программа закончит свое выполнение.");

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Введиете пароль: ");
                if (Console.ReadLine() == _pass)
                {
                    Console.WriteLine("Вы успешно ввели правильный пароль. Вход раззрещен.");
                    _message = true;
                    break;
                }
                else
                {
                    Console.WriteLine($"Пароль неверный. Осталось попыток {2 - i}");
                }
            }

            if (_message) Console.WriteLine("Вам показано cекретное сообщение.");
        }
    }
}

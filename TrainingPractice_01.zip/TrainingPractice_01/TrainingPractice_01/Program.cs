﻿using System;

namespace TrainingPractice_01
{
    class Program
    {
        static void Main(string[] args)
        {
            uint _cristal = 0;
            uint _gold;
            int _buy;
            string _end = "";
            while (true)
            {
                Console.WriteLine("Стоимость крисстала: 50");
                Console.Write("Введите ваше количество золота:  ");
                try
                {
                    _gold = UInt32.Parse(Console.ReadLine());                    
                    
                    while (_end != "end" && _gold >= 50) {
                        Console.WriteLine($"Ваше золото = {_gold}, вы можете купить {_gold / 50} кристаллов по цене 50 за шт. у вас {_cristal} кристаллов.");                                            
                        do  {
                            Console.WriteLine("Сколько кристаллов желаете купить?");
                            _buy = Convert.ToInt32(Console.ReadLine());
                        } while (_buy > (_gold / 50) || _buy < 0);
                        _cristal += Convert.ToUInt32(_buy);
                        _gold = _gold - Convert.ToUInt32(_buy) * 50;
                        Console.WriteLine($"Вы успешно купили {_buy} кристаллов.");
                        Console.WriteLine("Если желаете закончить введите end. Для продолжения нажмите enter.");
                        _end = Console.ReadLine();
                    }
                    Console.WriteLine($"Ваш баланс: золото:{_gold}, кристаллы: {_cristal}. Досвидания.");
                    return;
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                }               
            }
        }
    }
}

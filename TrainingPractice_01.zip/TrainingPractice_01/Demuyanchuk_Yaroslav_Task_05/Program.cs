﻿using System;
using System.IO;
using System.Linq;

namespace Demuyanchuk_Yaroslav_Task_05
{
    class Program
    {
        static void Main(string[] args)
        {
            GameClass myGame = new GameClass();
            myGame.StartGame();
        }

        
    }  
}

﻿using System;
using System.IO;
using static System.Console;

namespace Demuyanchuk_Yaroslav_Task_05
{
    internal class GameClass
    {
        int xPlayer = 1, yPlayer = 1;
        public static string[] _lines = File.ReadAllLines(@"C:\Users\JW\Desktop\TrainingPractice_01\Demuyanchuk_Yaroslav_Task_05\lab.txt");
        char[,] _element = new char[_lines.Length, _lines[0].Length];
        char[,] _enemyPos = new char[_lines.Length, _lines[0].Length];

        int _health = 100;

        public void StartGame()
        {
            for (int i = 0; i < _element.GetLength(0); i++)
            {
                for (int j = 0; j < _element.GetLength(1); j++)
                {
                    _element[i, j] = _lines[i][j];
                }
            }

            void Draw()
            {
                SetCursorPosition(0, 0);
                for (int i = 0; i <= _element.GetLength(0) - 1; i++)
                {

                    for (int j = 0; j <= _element.GetLength(1) - 1; j++)
                    {
                        if (_element[i, j] == '#') { Console.Write("█"); }
                        else if (_element[i, j] == ' ') { Console.Write(" "); }
                        else if (_element[i, j] == '☼') { Console.Write("☼"); }
                        else if (_element[i, j] == '☺') { Console.Write("☺"); }
                        else if (_element[i, j] == '♦') { Console.Write("♦"); }
                        else if (_element[i, j] == '♥') { Console.Write("♥"); }
                    }
                    Console.WriteLine();
                }
            }

            void Spawn()
            {
                var rndx = new Random();
                var rndy = new Random();
                int x, y, countEnemy = 0;
                int countHeal = 0;

                do
                {
                    x = rndx.Next(1, _element.GetLength(0) - 1);
                    y = rndy.Next(1, _element.GetLength(1) - 1);
                    if (_element[x, y] == ' ')
                    {
                        countEnemy++;
                        _element[x, y] = '♦';
                    }

                }
                while (countEnemy < 8);

                do
                {
                    x = rndx.Next(1, _element.GetLength(0) - 1);
                    y = rndy.Next(1, _element.GetLength(1) - 1);
                    if (_element[x, y] == ' ')
                    {
                        countHeal++;
                        _element[x, y] = '♥';
                    }

                }
                while (countHeal < 2);
            }

            void Move()
            {
                Boolean fin = true;
                int vector;


                while (fin)
                {
                    ConsoleKeyInfo info = Console.ReadKey(true);                   
                    switch (info.Key)
                    {
                        case ConsoleKey.UpArrow:
                            {
                                if (_element[yPlayer - 1, xPlayer] == ' ')
                                {
                                    _element[yPlayer - 1, xPlayer] = '☺';
                                    _element[yPlayer, xPlayer] = ' ';
                                    yPlayer--;
                                }
                                else if (_element[yPlayer - 1, xPlayer] == '♦')
                                {
                                    _health -= 30;
                                    _element[yPlayer - 1, xPlayer] = ' ';
                                }
                                else if (_element[yPlayer - 1, xPlayer] == '☼') { fin = false; }
                                else if (_element[yPlayer - 1, xPlayer] == '♥')
                                {
                                    _health += 15;
                                    _element[yPlayer - 1, xPlayer] = ' ';
                                }
                                MoveEnemy();
                                break;
                            }
                        case ConsoleKey.DownArrow:
                            {
                                if (_element[yPlayer + 1, xPlayer] == ' ')
                                {
                                    _element[yPlayer + 1, xPlayer] = '☺';
                                    _element[yPlayer, xPlayer] = ' ';
                                    yPlayer++;
                                }
                                else if (_element[yPlayer + 1, xPlayer] == '♦')
                                {
                                    _health -= 30;
                                    _element[yPlayer + 1, xPlayer] = ' ';
                                }
                                else if (_element[yPlayer + 1, xPlayer] == '☼') { fin = false; }
                                else if (_element[yPlayer + 1, xPlayer] == '♥')
                                {
                                    _health += 15;
                                    _element[yPlayer + 1, xPlayer] = ' ';
                                }
                                MoveEnemy();
                                break;
                            }
                        case ConsoleKey.LeftArrow:
                            {
                                if (_element[yPlayer, xPlayer - 1] == ' ')
                                {
                                    _element[yPlayer, xPlayer - 1] = '☺';
                                    _element[yPlayer, xPlayer] = ' ';
                                    xPlayer--;
                                }
                                else if (_element[yPlayer, xPlayer - 1] == '♦')
                                {
                                    _health -= 30;
                                    _element[yPlayer, xPlayer - 1] = ' ';
                                }
                                else if (_element[yPlayer, xPlayer - 1] == '☼') { fin = false; }
                                else if (_element[yPlayer, xPlayer - 1] == '♥')
                                {
                                    _health += 15;
                                    _element[yPlayer, xPlayer - 1] = ' ';
                                }
                                MoveEnemy();
                                break;
                            }
                        case ConsoleKey.RightArrow:
                            {
                                if (_element[yPlayer, xPlayer + 1] == ' ')
                                {
                                    _element[yPlayer, xPlayer + 1] = '☺';
                                    _element[yPlayer, xPlayer] = ' ';
                                    xPlayer++;

                                }
                                else if (_element[yPlayer, xPlayer + 1] == '♦')
                                {
                                    _health -= 30;
                                    _element[yPlayer, xPlayer + 1] = ' ';
                                }
                                else if (_element[yPlayer, xPlayer + 1] == '☼') { fin = false; }
                                else if (_element[yPlayer, xPlayer + 1] == '♥')
                                {
                                    _health += 15;
                                    _element[yPlayer, xPlayer + 1] = ' ';
                                }
                                MoveEnemy();
                                break;
                            }
                    }
                    Draw();
                    if (_health < 1)
                    {
                        fin = false;
                        Console.Clear();
                        Console.WriteLine("Вы умерли.");
                    }
                }

                if (_health > 0) { Console.Clear() ; Console.WriteLine("Вы победили"); }
            }

            void MoveEnemy()
            {
                Random rnd = new Random();
                int index = 0;

                for (int i = 0; i <= _element.GetLength(0) - 1; i++)
                {

                    for (int j = 0; j <= _element.GetLength(1) - 1; j++)
                    {
                        if (_element[i, j] == '♦')
                        {
                            index = rnd.Next(0, 4);
                            switch (index)
                            {
                                case 0:
                                    {
                                        if (_element[i - 1, j] == ' ')
                                        {
                                            _element[i - 1, j] = '♦';
                                            _element[i, j] = ' ';
                                        }
                                        break;
                                    }
                                case 1:
                                    {
                                        if (_element[i + 1, j] == ' ')
                                        {
                                            _element[i + 1, j] = '♦';
                                            _element[i, j] = ' ';
                                        }
                                        break;
                                    }
                                case 2:
                                    {
                                        if (_element[i, j - 1] == ' ')
                                        {
                                            _element[i, j - 1] = '♦';
                                            _element[i, j] = ' ';
                                        }
                                        break;
                                    }
                                case 3:
                                    {
                                        if (_element[i, j + 1] == ' ')
                                        {
                                            _element[i, j + 1] = '♦';
                                            _element[i, j] = ' ';
                                        }
                                        break;
                                    }
                            }
                        }
                    }
                }
                Console.WriteLine();
            }
       

            CursorVisible = false;
            Spawn();
            Draw();
            Move();
        }
    }
}


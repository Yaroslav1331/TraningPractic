﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SeaWars2
{
    public partial class Form1 : Form
    {
        public const int mapSize = 10;
        public int buttonSize = 30;
        public string alphabet = "АБВГДЕЖЗИК";

        public Button[,] myMap = new Button[mapSize, mapSize];
        public Button[,] enemyMap = new Button[mapSize, mapSize];
        public Button[] alphabetBut = new Button[mapSize];
        public Button[] numbersBut = new Button[mapSize];

        public int[,] enemyMapBut = new int[mapSize, mapSize];

        public int x;
        public int y;
        public int ship = 4;
        public int vector = 0;
        public bool startGame = false;
        public int move = 1;
        public int Number = 0;
        int win = 0, draw = 0;
        public bool call = true;
        public bool batRed = false;
        public bool ones = false;

        public int four = 1, three = 2, two = 3, one = 4;

        Label select = new Label();
        Button vector1 = new Button();
        Button vector2 = new Button();


        public Form1()
        {
            InitializeComponent();
            CreateMaps();
            Generate();
        }

        public void StartGame(object sender, EventArgs e)
        {
            x = myMap.GetLength(0);
            y = myMap.GetLength(1);

            if (four == 0 && three == 0 && two == 0 && one == 0) startGame = true;
            else MessageBox.Show("Вы неправильно расставили корабли!");

            if (startGame)
            {
                for (int i = 0; i < mapSize; i++)
                {
                    for (int j = 0; j < mapSize; j++)
                    {
                        if (myMap[i, j].BackColor == Color.Gray)
                        {
                            myMap[i, j].BackColor = Color.White;
                        }
                    }
                }
            }
        }
        public void CreateMaps()
        {
            Label map1 = new Label();
            map1.Text = "Игрок 1";
            map1.Location = new Point((mapSize + 1) * buttonSize / 2, (mapSize + 1) * buttonSize + 15);
            map1.ForeColor = Color.Red;
            this.Controls.Add(map1);

            Label map2 = new Label();
            map2.Text = "Игрок 2";
            map2.Location = new Point((mapSize + 1) * buttonSize + 300, (mapSize + 1) * buttonSize + 15);
            map2.ForeColor = Color.Blue;
            this.Controls.Add(map2);

            Button start = new Button();
            start.Location = new Point((mapSize + 1), (mapSize + 1) * buttonSize + 30);
            start.Text = "Начать игру";
            start.Size = new Size(buttonSize * 4, buttonSize);
            start.Click += new EventHandler(StartGame);
            this.Controls.Add(start);

            Button one = new Button();
            one.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 8);
            one.Text = "1 - палубный";
            one.Size = new Size(buttonSize * 4, buttonSize);
            one.Click += new EventHandler(SelectShip);
            this.Controls.Add(one);

            Button two = new Button();
            two.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 12);
            two.Text = "2 - палубный";
            two.Size = new Size(buttonSize * 4, buttonSize);
            two.Click += new EventHandler(SelectShip);
            this.Controls.Add(two);

            Button three = new Button();
            three.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 16);
            three.Text = "3 - палубный";
            three.Size = new Size(buttonSize * 4, buttonSize);
            three.Click += new EventHandler(SelectShip);
            this.Controls.Add(three);

            Button four = new Button();
            four.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 20);
            four.Text = "4 - палубный";
            four.Size = new Size(buttonSize * 4, buttonSize);
            four.Click += new EventHandler(SelectShip);
            this.Controls.Add(four);


            vector1.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 26);
            vector1.Text = "Горизонталь";
            vector1.BackColor = Color.DarkGray;
            vector1.Size = new Size(buttonSize * 4, buttonSize);
            vector1.Click += new EventHandler(SelectShip);
            this.Controls.Add(vector1);


            vector2.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1) * 30);
            vector2.Text = "Вертикаль";
            vector2.Size = new Size(buttonSize * 4, buttonSize);
            vector2.Click += new EventHandler(SelectShip);
            this.Controls.Add(vector2);


            select.Location = new Point((mapSize + 1) * buttonSize + 20, (mapSize + 1));
            select.Text = $"Выбрана установка {ship} - палубного корабля.";
            select.Size = new Size(buttonSize * 5, buttonSize * 3);
            this.Controls.Add(select);

            this.Width = (mapSize + 1) * 2 * buttonSize + 200;
            this.Height = (mapSize + 8) * buttonSize;

            for (int i = 0; i < mapSize; i++)
            {
                alphabetBut[i] = new Button();
                alphabetBut[i].Text = alphabet[i].ToString();
                alphabetBut[i].Location = new Point(buttonSize + i * buttonSize);
                alphabetBut[i].Size = new Size(buttonSize, buttonSize);
                alphabetBut[i].BackColor = Color.LightGray;
                this.Controls.Add(alphabetBut[i]);
            }
            for (int i = 0; i < mapSize; i++)
            {
                numbersBut[i] = new Button();
                numbersBut[i].Text = i.ToString();
                numbersBut[i].Location = new Point(0, buttonSize + i * buttonSize);
                numbersBut[i].Size = new Size(buttonSize, buttonSize);
                numbersBut[i].BackColor = Color.LightGray;
                this.Controls.Add(numbersBut[i]);
            }

            for (int i = 0; i < mapSize; i++)
            {
                for (int j = 0; j < mapSize; j++)
                {
                    myMap[i, j] = new Button();
                    myMap[i, j].Location = new Point(j * buttonSize + buttonSize, i * buttonSize + buttonSize);
                    myMap[i, j].Size = new Size(buttonSize, buttonSize);
                    myMap[i, j].BackColor = Color.White;
                    myMap[i, j].Click += new EventHandler(Configurate);
                    this.Controls.Add(myMap[i, j]);
                }
            }

            for (int i = 0; i < mapSize; i++)
            {
                alphabetBut[i] = new Button();
                alphabetBut[i].Text = alphabet[i].ToString();
                alphabetBut[i].Location = new Point(i * buttonSize + 500 + buttonSize);
                alphabetBut[i].Size = new Size(buttonSize, buttonSize);
                alphabetBut[i].BackColor = Color.LightGray;
                this.Controls.Add(alphabetBut[i]);
            }
            for (int i = 0; i < mapSize; i++)
            {
                numbersBut[i] = new Button();
                numbersBut[i].Text = i.ToString();
                numbersBut[i].Location = new Point(500, i * buttonSize + buttonSize);
                numbersBut[i].Size = new Size(buttonSize, buttonSize);
                numbersBut[i].BackColor = Color.LightGray;
                this.Controls.Add(numbersBut[i]);
            }

            for (int i = 0; i < mapSize; i++)
            {
                for (int j = 0; j < mapSize; j++)
                {
                    enemyMap[i, j] = new Button();
                    enemyMap[i, j].Location = new Point(j * buttonSize + 500 + buttonSize, i * buttonSize + buttonSize);
                    enemyMap[i, j].Size = new Size(buttonSize, buttonSize);
                    enemyMap[i, j].Click += new EventHandler(Shoot);
                    enemyMap[i, j].BackColor = Color.White;
                    this.Controls.Add(enemyMap[i, j]);
                }
            }
        }

        public void SelectShip(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            switch (btn.Text)
            {
                case "1 - палубный":
                    {
                        ship = 1;
                        select.Text = $"Выбрана установка {ship} - палубного корабля.";
                    }
                    break;
                case "2 - палубный":
                    {
                        ship = 2;
                        select.Text = $"Выбрана установка {ship} - палубного корабля.";
                    }
                    break;
                case "3 - палубный":
                    {
                        ship = 3;
                        select.Text = $"Выбрана установка {ship} - палубного корабля.";
                    }
                    break;
                case "4 - палубный":
                    {
                        ship = 4;
                        select.Text = $"Выбрана установка {ship} - палубного корабля.";
                    }
                    break;
                case "Горизонталь":
                    {
                        vector = 0;
                        vector1.BackColor = Color.DarkGray;
                        vector2.BackColor = Color.White;
                    }
                    break;
                case "Вертикаль":
                    {
                        vector = 1;
                        vector2.BackColor = Color.DarkGray;
                        vector1.BackColor = Color.White;
                    }
                    break;
            }
        }
        public void Configurate(object sender, EventArgs e)
        {
            batRed = false;
            if (!startGame)
            {
                for (int i = 0; i < mapSize; i++)
                {
                    for (int j = 0; j < mapSize; j++)
                    {
                        if (myMap[i, j] == sender)
                        {
                            switch (ship)
                            {
                                case 1:
                                    {

                                        if (myMap[i, j].BackColor == Color.White)
                                        {
                                            if (one > 0)
                                            {
                                                one--;
                                                myMap[i, j].BackColor = Color.Red;
                                            }
                                        }
                                        else if (myMap[i, j].BackColor == Color.Red)
                                        {
                                            try { if (myMap[i + 1, j].BackColor == Color.Red) { ones = true; } }
                                            catch (IndexOutOfRangeException) { }
                                            try { if (myMap[i - 1, j].BackColor == Color.Red) { ones = true; } }
                                            catch (IndexOutOfRangeException) { }
                                            try { if (myMap[i, j + 1].BackColor == Color.Red) { ones = true; } }
                                            catch (IndexOutOfRangeException) { }
                                            try { if (myMap[i, j - 1].BackColor == Color.Red) { ones = true; } }
                                            catch (IndexOutOfRangeException) { }

                                            if (!ones)
                                            {
                                                one++;
                                                myMap[i, j].BackColor = Color.White;
                                            }
                                        }
                                        ones = false;
                                    }
                                    break;
                                case 2:
                                    {

                                        if (myMap[i, j].BackColor == Color.White)
                                        {
                                            if (two > 0)
                                            {
                                                if (vector == 0)
                                                {
                                                    if (j + 1 < mapSize && myMap[i, j + 1].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i, j + 1].BackColor = Color.Red;
                                                        two--;
                                                    }
                                                }
                                                else
                                                {
                                                    if (i + 1 < mapSize && myMap[i + 1, j].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i + 1, j].BackColor = Color.Red;
                                                        two--;
                                                    }
                                                }
                                            }
                                        }
                                        else if (myMap[i, j].BackColor == Color.Red)
                                        {
                                            if (vector == 0)
                                            {
                                                try
                                                {
                                                    if (j + 1 < mapSize && myMap[i, j + 1].BackColor == Color.Red)
                                                    {
                                                        if (j - 1 < 0 && myMap[i, j + 2].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            two++;
                                                        }
                                                        else if (j + 2 >= mapSize && myMap[i, j - 1].BackColor != Color.Red)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            two++;
                                                        }
                                                        else if (myMap[i, j - 1].BackColor != Color.Red && myMap[i, j + 2].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            two++;
                                                        }
                                                    }
                                                }
                                                catch (IndexOutOfRangeException) { }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (i + 1 < mapSize && myMap[i + 1, j].BackColor == Color.Red)
                                                    {
                                                        if (i - 1 < 0 && myMap[i + 2, j].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            two++;
                                                        }
                                                        else if (i + 2 >= mapSize && myMap[i - 1, j].BackColor != Color.Red)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            two++;
                                                        }
                                                        else if (myMap[i - 1, j].BackColor != Color.Red && myMap[i + 2, j].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            two++;
                                                        }
                                                    }
                                                }
                                                catch (IndexOutOfRangeException) { }
                                            }
                                        }
                                    }

                                    break;

                                case 3:
                                    {

                                        if (myMap[i, j].BackColor == Color.White)
                                        {
                                            if (three > 0)
                                            {
                                                if (vector == 0)
                                                {
                                                    if (j + 2 < mapSize && myMap[i, j + 1].BackColor != Color.Gray && myMap[i, j + 2].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i, j + 1].BackColor = Color.Red;
                                                        myMap[i, j + 2].BackColor = Color.Red;
                                                        three--;
                                                    }
                                                }
                                                else
                                                {
                                                    if (i + 2 < mapSize && myMap[i + 1, j].BackColor != Color.Gray && myMap[i + 2, j].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i + 1, j].BackColor = Color.Red;
                                                        myMap[i + 2, j].BackColor = Color.Red;
                                                        three--;
                                                    }
                                                }
                                            }
                                        }
                                        else if (myMap[i, j].BackColor == Color.Red)
                                        {
                                            if (vector == 0)
                                            {
                                                try
                                                {
                                                    if (j + 1 < mapSize && myMap[i, j + 1].BackColor == Color.Red && myMap[i, j + 2].BackColor == Color.Red)
                                                    {
                                                        if (j - 1 < 0 && myMap[i, j + 3].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            myMap[i, j + 2].BackColor = Color.White;
                                                            three++;
                                                        }
                                                        else if (j + 3 >= mapSize && myMap[i, j - 1].BackColor != Color.Red)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            myMap[i, j + 2].BackColor = Color.White;
                                                            three++;
                                                        }
                                                        else if (myMap[i, j - 1].BackColor != Color.Red && myMap[i, j + 3].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i, j + 1].BackColor = Color.White;
                                                            myMap[i, j + 2].BackColor = Color.White;
                                                            three++;
                                                        }
                                                    }
                                                }
                                                catch (IndexOutOfRangeException) { }
                                            }
                                            else
                                            {
                                                try
                                                {
                                                    if (i + 1 < mapSize && myMap[i + 1, j].BackColor == Color.Red && myMap[i + 2, j].BackColor == Color.Red)
                                                    {
                                                        if (i - 1 < 0 && myMap[i + 3, j].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            myMap[i + 2, j].BackColor = Color.White;
                                                            three++;
                                                        }
                                                        else if (i + 3 >= mapSize && myMap[i - 1, j].BackColor != Color.Red)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            myMap[i + 2, j].BackColor = Color.White;
                                                            three++;
                                                        }
                                                        else if (myMap[i - 1, j].BackColor != Color.Red && myMap[i + 3, j].BackColor == Color.Gray)
                                                        {
                                                            myMap[i, j].BackColor = Color.White;
                                                            myMap[i + 1, j].BackColor = Color.White;
                                                            myMap[i + 2, j].BackColor = Color.White;
                                                            three++;
                                                        }
                                                    }
                                                }
                                                catch (IndexOutOfRangeException) { }
                                            }
                                        }
                                    }
                                    break;
                                case 4:
                                    {

                                        if (myMap[i, j].BackColor == Color.White)
                                        {
                                            if (four > 0)
                                            {
                                                if (vector == 0)
                                                {
                                                    if (j + 3 < mapSize && myMap[i, j + 1].BackColor != Color.Gray && myMap[i, j + 2].BackColor != Color.Gray && myMap[i, j + 3].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i, j + 1].BackColor = Color.Red;
                                                        myMap[i, j + 2].BackColor = Color.Red;
                                                        myMap[i, j + 3].BackColor = Color.Red;
                                                        four--;
                                                    }
                                                }
                                                else
                                                {
                                                    if (i + 3 < mapSize && myMap[i + 1, j].BackColor != Color.Gray && myMap[i + 2, j].BackColor != Color.Gray && myMap[i + 3, j].BackColor != Color.Gray)
                                                    {
                                                        myMap[i, j].BackColor = Color.Red;
                                                        myMap[i + 1, j].BackColor = Color.Red;
                                                        myMap[i + 2, j].BackColor = Color.Red;
                                                        myMap[i + 3, j].BackColor = Color.Red;
                                                        four--;
                                                    }
                                                }
                                            }
                                        }
                                        else if (myMap[i, j].BackColor == Color.Red)
                                        {
                                            if (vector == 0)
                                            {
                                                if (j + 3 < mapSize && myMap[i, j + 1].BackColor == Color.Red && myMap[i, j + 2].BackColor == Color.Red && myMap[i, j + 3].BackColor == Color.Red)
                                                {
                                                    myMap[i, j].BackColor = Color.White;
                                                    myMap[i, j + 1].BackColor = Color.White;
                                                    myMap[i, j + 2].BackColor = Color.White;
                                                    myMap[i, j + 3].BackColor = Color.White;
                                                    four++;
                                                }
                                            }
                                            else
                                            {
                                                if (i + 3 < mapSize && myMap[i + 1, j].BackColor == Color.Red && myMap[i + 2, j].BackColor == Color.Red && myMap[i + 3, j].BackColor == Color.Red)
                                                {
                                                    myMap[i, j].BackColor = Color.White;
                                                    myMap[i + 1, j].BackColor = Color.White;
                                                    myMap[i + 2, j].BackColor = Color.White;
                                                    myMap[i + 3, j].BackColor = Color.White;
                                                    four++;
                                                }
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                    }
                }

                for (int i = 0; i < mapSize; i++)
                {
                    for (int j = 0; j < mapSize; j++)
                    {
                        if (myMap[i, j].BackColor == Color.Gray)
                        {
                            try { if (myMap[i - 1, j - 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i - 1, j].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i - 1, j + 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i, j - 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i, j + 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j - 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j + 1].BackColor == Color.Red) batRed = true; } catch (IndexOutOfRangeException) { }

                            if (!batRed)
                            {
                                myMap[i, j].BackColor = Color.White;
                            }
                        }
                        batRed = false;
                    }
                }

                for (int i = 0; i < mapSize; i++)
                {
                    for (int j = 0; j < mapSize; j++)
                    {
                        if (myMap[i, j].BackColor == Color.Red)
                        {
                            try { if (myMap[i - 1, j - 1].BackColor == Color.White) myMap[i - 1, j - 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i - 1, j].BackColor == Color.White) myMap[i - 1, j].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i - 1, j + 1].BackColor == Color.White) myMap[i - 1, j + 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i, j - 1].BackColor == Color.White) myMap[i, j - 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i, j + 1].BackColor == Color.White) myMap[i, j + 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j - 1].BackColor == Color.White) myMap[i + 1, j - 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j].BackColor == Color.White) myMap[i + 1, j].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                            try { if (myMap[i + 1, j + 1].BackColor == Color.White) myMap[i + 1, j + 1].BackColor = Color.Gray; } catch (IndexOutOfRangeException) { }
                        }
                    }
                }
            }           
        }
            public void Win()
            {
                if (win >= 20)
                {
                    startGame = false;
                    MessageBox.Show("Вы победили!");
                }
                if (draw >= 20)
                {
                    startGame = false;
                    MessageBox.Show("Вы проиграли!");
                }
            }
            public void Shoot(object sender, EventArgs e)
            {
                if (startGame)
                {
                    for (int j = 0; j < mapSize; j++)
                    {
                        for (int i = 0; i < mapSize; i++)
                        {
                            if (enemyMap[i, j] == sender)
                            {
                                if (enemyMapBut[i, j] == 1)
                                {
                                    enemyMap[i, j].BackColor = Color.Pink;
                                    enemyMap[i, j].Text = "X";
                                    win++;
                                    call = false;
                                }
                                else { enemyMap[i, j].BackColor = Color.LightGray; call = true; }
                            }
                        }
                    }
                    Win();
                    if (call) EnemyShoot();
                }
            }

            public void EnemyShoot()
            {

                select.Text = "Ваш ход";
                Random rnd = new Random();
                int x, y;
            link1:
                x = rnd.Next(0, 10);
                y = rnd.Next(0, 10);

                if (myMap[x, y].BackColor == Color.Red)
                {
                    myMap[x, y].BackColor = Color.LightBlue;
                    myMap[x, y].Text = "X";
                    draw++;
                    try
                    {
                        if (myMap[x + 1, y].BackColor == Color.Red)
                        {
                            myMap[x + 1, y].BackColor = Color.LightBlue;
                            myMap[x + 1, y].Text = "X";
                            draw++;
                            if (myMap[x + 2, y].BackColor == Color.Red)
                            {
                                myMap[x + 2, y].BackColor = Color.LightBlue;
                                myMap[x + 2, y].Text = "X";
                                draw++;
                                if (myMap[x + 3, y].BackColor == Color.Red)
                                {
                                    myMap[x + 3, y].BackColor = Color.LightBlue;
                                    myMap[x + 3, y].Text = "X";
                                    draw++;
                                }
                            }
                        }
                    }
                    catch { }
                    try
                    {
                        if (myMap[x - 1, y].BackColor == Color.Red)
                        {
                            myMap[x - 1, y].BackColor = Color.LightBlue;
                            myMap[x - 1, y].Text = "X";
                            draw++;
                            if (myMap[x - 2, y].BackColor == Color.Red)
                            {
                                myMap[x - 2, y].BackColor = Color.LightBlue;
                                myMap[x - 2, y].Text = "X";
                                draw++;
                                if (myMap[x - 3, y].BackColor == Color.Red)
                                {
                                    myMap[x - 3, y].BackColor = Color.LightBlue;
                                    myMap[x - 3, y].Text = "X";
                                    draw++;
                                }
                            }
                        }
                    }
                    catch { }
                    try
                    {
                        if (myMap[x, y + 1].BackColor == Color.Red)
                        {
                            myMap[x, y + 1].BackColor = Color.LightBlue;
                            myMap[x, y + 1].Text = "X";
                            draw++;
                            if (myMap[x, y + 2].BackColor == Color.Red)
                            {
                                myMap[x, y + 2].BackColor = Color.LightBlue;
                                myMap[x, y + 2].Text = "X";
                                draw++;
                                if (myMap[x, y + 3].BackColor == Color.Red)
                                {
                                    myMap[x, y + 3].BackColor = Color.LightBlue;
                                    myMap[x, y + 3].Text = "X";
                                    draw++;
                                }
                            }
                        }
                    }
                    catch { }
                    try
                    {
                        if (myMap[x, y - 1].BackColor == Color.Red)
                        {
                            myMap[x, y - 1].BackColor = Color.LightBlue;
                            myMap[x, y - 1].Text = "X";
                            draw++;
                            if (myMap[x, y - 2].BackColor == Color.Red)
                            {
                                myMap[x, y - 2].BackColor = Color.LightBlue;
                                myMap[x, y - 2].Text = "X";
                                draw++;
                                if (myMap[x, y - 3].BackColor == Color.Red)
                                {
                                    myMap[x, y - 3].BackColor = Color.LightBlue;
                                    myMap[x, y - 3].Text = "X";
                                    draw++;
                                }
                            }
                        }
                    }
                    catch { }
                }
                else if (myMap[x, y].BackColor == Color.LightBlue) goto link1;
                else
                {
                    myMap[x, y].BackColor = Color.LightGray;
                }
                Win();
            }

            public void Generate()
            {

                Number = 0;
                Four();
                while (Number < three)
                {
                    Three();
                }
                Number = 0;
                while (Number < two)
                {
                    Two();
                }
                Number = 0;
                while (Number < one)
                {
                    One();
                }
            }

            private void Four()
            {
                var random = new Random();
                int x = random.Next(10);
                int y = random.Next(10);
                if (x > 5)
                {
                    y = random.Next(5);
                    for (int i = y; i < y + 4; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                    return;
                }
                if (y > 5)
                {
                    x = random.Next(5);
                    for (int j = x; j < x + 4; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                    return;
                }
                int k = random.Next(1);
                if (k == 0)
                {
                    for (int i = y; i < y + 4; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                }
                else
                {
                    for (int j = x; j < x + 4; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                }
            }
            private void Three()
            {
                var random = new Random();
                var x = random.Next(10);
                var y = random.Next(10);
                if (y > 6)
                {
                    x = random.Next(7);
                    for (int i = y - 1; i < y + 2; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 4; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int j = x; j < x + 3; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                    Number++;
                    return;
                }
                if (x > 6)
                {
                    y = random.Next(7);
                    for (int i = y - 1; i < y + 4; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 2; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            {
                                if (enemyMapBut[i, j] != 0)
                                {
                                    return;
                                }
                            }
                        }
                    }
                    for (int i = y; i < y + 3; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                    Number++;
                    return;
                }
                int k = random.Next(1);
                if (k == 0)
                {
                    for (int i = y - 1; i < y + 4; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 2; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int i = y; i < y + 3; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                    Number++;
                }
                else
                {
                    for (int i = y - 1; i < y + 2; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 4; j++)
                        {
                            if (j < 0)
                            {
                                j = 0;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int j = x; j < x + 3; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                    Number++;
                }
            }
            private void Two()
            {
                var random = new Random();
                var x = random.Next(10);
                var y = random.Next(10);
                if (y > 7)
                {
                    x = random.Next(8);
                    for (int i = y - 1; i < y + 2; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 3; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int j = x; j < x + 2; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                    Number++;
                    return;
                }
                if (x > 7)
                {
                    y = random.Next(8);
                    for (int i = y - 1; i < y + 3; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 2; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int i = y; i < y + 2; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                    Number++;
                    return;
                }
                int k = random.Next(1);
                if (k == 0)
                {
                    for (int i = y - 1; i < y + 3; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 2; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int i = y; i < y + 2; i++)
                    {
                        enemyMapBut[i, x] = 1;
                    }
                    Number++;
                }
                else
                {
                    for (int i = y - 1; i < y + 2; i++)
                    {
                        if (i < 0)
                        {
                            i++;
                        }
                        if (i > 9)
                        {
                            break;
                        }
                        for (int j = x - 1; j < x + 3; j++)
                        {
                            if (j < 0)
                            {
                                j++;
                            }
                            if (j > 9)
                            {
                                break;
                            }
                            if (enemyMapBut[i, j] != 0)
                            {
                                return;
                            }
                        }
                    }
                    for (int j = x; j < x + 2; j++)
                    {
                        enemyMapBut[y, j] = 1;
                    }
                    Number++;
                }
            }
            private void One()
            {
                var random = new Random();
                var x = random.Next(10);
                var y = random.Next(10);
                for (int i = y - 1; i < y + 2; i++)
                {
                    if (i < 0)
                    {
                        i++;
                    }
                    if (i > 9)
                    {
                        break;
                    }
                    for (int j = x - 1; j < x + 2; j++)
                    {
                        if (j < 0)
                        {
                            j++;
                        }
                        if (j > 9)
                        {
                            break;
                        }
                        if (enemyMapBut[i, j] != 0)
                        {
                            return;
                        }
                    }
                }
                enemyMapBut[y, x] = 1;
                Number++;
            }

        }
    }


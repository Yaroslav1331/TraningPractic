﻿using System;

namespace Demuyanchuk_Yaroslav_Task_07
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int _number, n = 0;
            Random rnd = new Random();

            Console.WriteLine("Введите кол-во элементов массива: ");
            _number = Convert.ToInt32(Console.ReadLine());

            string[] _mass = new string[_number];
            string[] _shuffleMass = new string[_number];

            Console.WriteLine("Исходный массив: ");
            for (int i = 0; i < _mass.Length ; i++)
            {
                _mass[i] = Convert.ToString(rnd.Next(0, 100));
                Console.Write(_mass[i] + " ");
            }
            Console.WriteLine();

            Shuffle(_mass, _shuffleMass, n, _number);

            Console.WriteLine("Перемешанный массив: ");
            for(int i = 0; i < _mass.Length; i++)
            {
                Console.Write(_shuffleMass[i] + " ");
            }
            Console.ReadKey();
        }   
        
        public static void Shuffle(string[] _mass,string[] _shuffleMass, int n, int _number)
        {
            Random rnd = new Random();
            for (int i = 0; i < _mass.Length; i++)
            {
                while (true)
                {
                    n = rnd.Next(0, _number);
                    if (_shuffleMass[n] == null)
                    {
                        _shuffleMass[n] = Convert.ToString(_mass[i]);
                        break;
                    }
                }
            }
            _mass = _shuffleMass;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demuyanchuk_Yaroslav_Task_04
{
    public class Info
    {
        Random rnd = new Random();
        private int health;
        private int manapool;
        private int damage;

        private int healthBoss;
        private int damageBoss;

        private int rashamonС = 0;
        private int hugansacuraС = 0;
        private int riftC = 0;
        private int comebackC = 0;
        private int save = 0;

        public int Manapool { get => manapool; set => manapool = value; }
        public int Damage { get => damage; set => damage = value; }
        public int HealthBoss { get => healthBoss; set => healthBoss = value; }
        public int DamageBoss { get => damageBoss; set => damageBoss = value; }
        public int RashamonC { get => rashamonС; set => rashamonС = value; }
        public int HugansacuraC { get => hugansacuraС; set => hugansacuraС = value; }
        public int Health { get => health; set => health = value; }
        public int RiftC { get => riftC; set => riftC = value; }
        public int ComebackC { get => comebackC; set => comebackC = value; }
        public int Save { get => save; set => save = value; }

        public void Rashamon()
        {

            if ((Health > 100) && (Manapool > 50))
            {
                Console.WriteLine("Вы призвали теневого духа. Это отняло у вас 100 здоровья и 50 маны.");
                health -= 100; manapool -= 50;
                rashamonС = 3;
            }
            else Console.WriteLine("У вас недостаточно ресурсов для использования заклинания.\n");
            rashamonС = 3;
        }

        public void Hugansacura()
        {
            if ((health > 100) && (manapool > 50))
            {
                Console.WriteLine("Вы использовали заклинание hugansacura. Это отняло у вас 200 здоровья и 100 маны.\n" +
                    "Ваш теневой дух повысился до стража. Теперь он наносит 300 урона и живет 5 ходов.\n");
                health -= 200; manapool -= 100;
                hugansacuraС = 5;
                rashamonС = 0;
            }
            else Console.WriteLine("У вас недостаточно ресурсов для использования заклинания.\n");

        }

        public void Rift()
        {
            if (riftC == 0 && manapool > 100)
            {
                Console.WriteLine("Вы скрылись в межпространственном разломе.\n" +
                    "Ваш уровень здоровья вырос на 250.\n" +
                    "Вы потратили 100 маны.");
                if (health > 1250) health = 1500;
                else health += 250;
                riftC = 1;
                manapool -= 100;
            }
            else Console.WriteLine("У вас недостаточно ресурсов для использования заклинания. Или вы уже находитесь в разломе.\n");
        }

        public void Comeback()
        {
            if (riftC > 0)
            {
                Console.WriteLine("Вы вернулись из разлома. Противник оглушен на 1 ход.");
                riftC = 0;
                comebackC = 1;
            }
            else Console.WriteLine("Вы не находитесь в разломе.");
        }

        public void Chidori()
        {
            if (manapool > 150)
            {
                Console.WriteLine("Вы использовали заклинание молнии. Нанесли врагу 350 урона и оглушили.\n" +
                    "Потратили 150 маны.");
                healthBoss -= 350;
                manapool -= 150;
            }
            else Console.WriteLine("У вас недостаточно ресурсов для использования заклинания.\n");
        }
            
        public void Morrowind()
        {
            if (save > 1)
            {
                Console.WriteLine("Вы использование заклинание восстановления маны. Восстаносили 100 маны.");
                manapool += 100;
                save = 0;
            }
            else Console.WriteLine("Похоже вы получали урон последние 2 хода.");
        }
    }
}

﻿using System;

namespace Demuyanchuk_Yaroslav_Task_04
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Info info = new Info();
            Random rnd = new Random();

            //Свойства игры
            bool _startgame = true;
            string _spell = "";

            //Свойства игрока
            info.Health = rnd.Next(1000, 1200);
            info.Manapool = rnd.Next(500, 700);
            info.Damage = rnd.Next(50, 100);

            //Свойства босса
            info.HealthBoss = rnd.Next(3000, 4000);
            info.DamageBoss = rnd.Next(100, 200);

            Console.WriteLine("Вы странник только что очнувшийся в неизвестной пещере...\n " +
                "Вы видите перед собой страшное чудовище настроеное к вам враждебно, думаю вам стоит приготовиться к бою! \n" +
                "Вы замечаете ваш дневник с заклинания, которые изучали ранее, они вам пригодятся. Так же у вас имеется корманный нож. \n" +
                "Список заклинаний: \n" +
                "\n" +
                $"Урон с помощью ножа: {info.Damage}. Чтобы ударить ножом введите : attack\n" +
                "Оценив противника вы понимаете что этот монстр - Огромный Паук. \n" +
                "Его характеристики: \n" +
                $"Уровень здоровья: {info.HealthBoss}\n" +
                $"Оценив свое состояние вы понимаете что уровень вашего текущего здоровья равен {info.Health}.\n" +
                $"Количество вашей маны: {info.Manapool}.\n" +
                $"Бой начинается!\n \n ");

            int _coin = rnd.Next(0, 2);
            if (_coin == 0) Console.WriteLine("Вам подвернулась удача! Вы начинаете ход.");
            else Console.WriteLine("Вам не повезло. Ход начиниет противник!");

            while (_startgame)
            {
                Console.WriteLine("-------------------------------------------");
                if (info.Health < 1)
                {
                    Console.WriteLine("Вас убили.\n" +
                                      "Игра окончена.");
                    _startgame = false;
                }
                else if (info.HealthBoss < 1)
                {
                    Console.WriteLine("Поздравляем! Вы убили босса!\n" +
                                      "Игра окончена.\n");
                    _startgame = false;
                }
                else
                {
                    if (_coin == 0)
                    {
                        if (info.RashamonC > 0)
                        {
                            Console.WriteLine($"Ваш теневой дух нанес боссу 100 урона.");
                            info.HealthBoss -= 100;
                            info.RashamonC--;
                        }

                        if (info.HugansacuraC > 0)
                        {
                            Console.WriteLine($"Ваш теневой страж нанес боссу 300 урона.");
                            info.HealthBoss -= 300;
                            info.HugansacuraC--;
                        }
                        Console.WriteLine($"Ваше здоровье: {info.Health}, ваш запас маны {info.Manapool}. \n" +
                                            $"Здоровье босса {info.HealthBoss}. \n");
                        Console.WriteLine("Ваш ход. Введите заклинание или ударьте ножом.\n" +
                                            "Чтобы посмотреть ваши заклинания введите help.\n");
                        _spell = Console.ReadLine();

                        if (_spell == "help")
                        {
                            Help();
                            Console.WriteLine("Введите заклинание или ударьте ножом.\n");
                            _spell = Console.ReadLine();
                        }
                        switch (_spell)
                        {                           
                            case "attack":
                                if (info.RiftC != 1)
                                {
                                    Console.WriteLine($"Вы ударили босса ножом и нанесли ему {info.Damage} урона.\n");
                                    info.HealthBoss -= info.Damage;
                                }
                                else Console.WriteLine("Вы находитесб в разломе, атаковать нельзя.");
                                break;
                            case "rashamon":
                                Console.WriteLine($"Вы использовали заклинание {_spell}.\n");
                                info.Rashamon();
                                break;
                            case "hugansacura":
                                if (info.RashamonC > 0)
                                {
                                    info.Hugansacura();
                                }
                                else Console.WriteLine("У вас нет теневого духа. Заклинание не удалось.\n");
                                break;
                            case "rift":
                                info.Rift();
                                break;
                            case "comeback":
                                info.Comeback();
                                break;
                            case "chidori":
                                if (info.RiftC != 1)
                                {
                                    info.Chidori();
                                }
                                break;
                            case "morrowind":
                                info.Morrowind();
                                break;

                            default:
                                Console.WriteLine("Похоже вы произнесли неверное заклинание, из-за потраченых сил вы потеряли 25 маны.\n" +
                                    "Ход переходит к сопернику.\n");
                                info.Manapool -= 25;
                                break;
                        }
                        _coin++;
                    }
                    else
                    {
                        Console.WriteLine("Ход противника.");
                        if (info.RiftC > 0 || info.ComebackC == 1)
                        {
                            if (info.ComebackC == 1)
                            {
                                info.ComebackC = 0;
                            }
                            Console.WriteLine("Босс не нанес вам урона.\n");
                            info.Save++;
                        }
                        else
                        {
                            info.DamageBoss = rnd.Next(100, 200);
                            info.Health -= info.DamageBoss;
                            info.Save = 0;
                            Console.WriteLine($"Босс атаковал и нанес вам {info.DamageBoss} урона.\n");                           
                        }
                        _coin--;
                    }
                }
            }
        }

        static void Help()
        {
            Console.WriteLine("Список заклинаний: \n" +
                "rashamon - вызываете теневого духа, теряя 100 здоровья. Затраты маны - 50.\n" +
                "Теневой дух живет 3 ваших хода, после чего изчезает.\n" +
                "Каждый ход, начиная со следующего, отнимает у босса 100 очков здоровья.\n" +
                "Не может быть призван снова пока не исчезнет.\n");
            Console.WriteLine("hugansacura - может быть использовано если призван теневой дух. \n" +
                "Отнимает у вас 200 здоровья и 100 маны." +
                "Улучшает вашего духа, теперь это теневой страж.\n" +
                "Его урон увеличен до 300, а так же иногда может принять урон босса на себя. Живет 5 ходов.\n" +
                "Не может быть призван снова пока не исчезнет.\n");
            Console.WriteLine("rift - заклинание вызывающее межпространственный пролом. \n" +
                "Вы можете скрыться в нем нексколько ходов. При этом ни вы ни босс не сможете атаковать друг друга. \n" +
                "Ваше здоровье еденично восстановится на 250, но не больше 1500.\n" +
                "Стоит 100 маны.\n");
            Console.WriteLine("comeback - заклинание возвращения из разлома. При возвращении оглушает босса на 1 ход.\n");
            Console.WriteLine("chidori - заклинание молнии. Вы концентрируете заряд в руке и наносите удар противнику.\n" +
                "Атака наносит 350 урона и оглушает жертву. При оглушении жертва наносит в 2 раза меньше урона.\n" +
                "Цена - 150 маны.\n");
            Console.WriteLine("morrowind - заклинание восстановления маны. Может быть использована, если игрок \n" +
                "не получал в последние 2 хода урон. Восстанавливает 100 маны.");
        }             
    }
}

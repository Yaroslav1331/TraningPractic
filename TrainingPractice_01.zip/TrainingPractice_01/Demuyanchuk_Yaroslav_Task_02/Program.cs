﻿using System;

namespace Demuyanchuk_Yaroslav_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Программа повторитель. Повторяет ваши сообщения. Для выхода введите exit.");
            string _message = "";
            while (_message != "exit")  {
                Console.WriteLine("Введите сообщение: ");
                _message = Console.ReadLine();
                Console.WriteLine($"Повторяем: {_message}");
            }
        }
    }
}
